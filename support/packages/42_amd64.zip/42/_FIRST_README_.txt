Code is from:
https://gitdev.faircon.net:8443/log/sourceforge%2Ffortytwospacecraftsimulation.git/refs%2Fheads%2Fstf-1-simulation

Branch is stf-1-simulation, the file git-log.txt shows the commit log which shows what commit this code came from.

Code was built and zipped on Ubuntu 32 bit by changing to the directory containing this file and then running ./Utilities/make_and_zip.sh (you might have to run dos2unix on this script first)

Many unneeded files were deleted until 42 still ran on Ubuntu 32 (try to reduce size) before finalizing the ./Utilities/ziplist.txt used by the script.

The readme's from the 42 directory and the directory above that were kept.

At the end of the script everything is zipped so it could be committed to the STF-1 repository for installation on the VM.

